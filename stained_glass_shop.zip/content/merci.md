+++
title = "Merci pour votre commande"
url = "/merci/"
+++

<h1>Merci ! 🎉</h1>
<p>Votre commande a bien été reçue. Nous la traitons avec soin.</p>
<p>Un email de confirmation vous sera envoyé sous peu.</p>
