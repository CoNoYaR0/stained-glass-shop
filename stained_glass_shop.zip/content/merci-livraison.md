---
title: "Merci pour votre commande"
url: "/merci-livraison"
layout: "default"
---

<h2>✅ Merci pour votre commande !</h2>

<p>Votre demande a bien été enregistrée. 📦</p>

<p>Vous serez contacté(e) très prochainement par notre équipe afin de :</p>
<ul>
  <li>Confirmer les détails de votre commande</li>
  <li>Valider votre bon de livraison</li>
  <li>Fixer une date de livraison</li>
</ul>

<p>Nous restons à votre disposition pour toute question complémentaire.</p>